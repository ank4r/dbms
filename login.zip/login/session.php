<?php
   
   session_start();
   
   $user_check = $_SESSION['login_user'];

   $sql = "SELECT userid FROM members where fname = \'".$user_check." \' ";
   
   $ses_sql = mysqli_query($db,$sql);
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['fname'];
   
   if(!isset($_SESSION['login_user'])){
	    header("location:../login/login.php");
   }
?>
