<?php
	$dbhost = 'localhost:3306';
   	$dbuser = 'root';
   	$dbpass = 'naruto';
?>
